Para instalar as dependencias rodar
```
npm install
```

Para executar o projeto rodar
```
npm start
```
