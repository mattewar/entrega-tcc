interface Image {
    [key: string]: any;
}

const images: Image = {
    image1: require('./images/1.png'),
    image2: require('./images/2.png'),
    image3: require('./images/3.png'),
    image4: require('./images/4.png'),
    image5: require('./images/5.png'),
    image6: require('./images/6.png'),
    image7: require('./images/7.png'),
    image8: require('./images/8.png'),
    image9: require('./images/9.png'),
    image10: require('./images/10.png'),
    image11: require('./images/11.png'),
    image12: require('./images/12.png'),
    image13: require('./images/13.png'),
    image14: require('./images/14.png'),
    image15: require('./images/15.png'),
    image16: require('./images/16.png'),
    image17: require('./images/17.png'),
    image18: require('./images/18.png'),
    image19: require('./images/19.png'),
    image20: require('./images/20.png'),
    image21: require('./images/21.png'),
}

export default images;