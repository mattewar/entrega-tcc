# Aplicativo E-doso

Esse é o repositório do aplicativo E-DOSO, desenvolvido como Trabalho de Conclusão de Curso, do curso de Análise e Desenvolvimento de Sistemas da Universidade Federal do Paraná

### Requisitos para instalação:
    - npx

### Rode o projeto:
   
    npx react-native start
    npx react-native run-android
