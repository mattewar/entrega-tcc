Para instalar as dependencias rodar
```
npm install
```

Para executar o projeto rodar
```
npm run dev
```

Exemplos das requisições podem ser achados na collection do postman